-- MySQL dump 10.10
--
-- Host: localhost    Database: csecvm
-- ------------------------------------------------------
-- Server version	5.0.15-standard

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `basket`
--

DROP TABLE IF EXISTS `basket`;
CREATE TABLE `basket` (
  `user_id` int(11) NOT NULL default '0',
  `product_id` int(11) NOT NULL default '0',
  `quantity` int(11) default NULL,
  PRIMARY KEY  (`user_id`,`product_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `basket_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `basket_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `basket`
--


/*!40000 ALTER TABLE `basket` DISABLE KEYS */;
LOCK TABLES `basket` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `basket` ENABLE KEYS */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) default NULL,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `cc` varchar(16) default NULL,
  `cvv` varchar(3) default NULL,
  `expire` date default NULL,
  `outfordelivery` tinyint(1) default '0',
  PRIMARY KEY  (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--


/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
LOCK TABLES `orders` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;

--
-- Table structure for table `orders_items`
--

DROP TABLE IF EXISTS `orders_items`;
CREATE TABLE `orders_items` (
  `id` int(11) NOT NULL auto_increment,
  `order_id` int(11) default NULL,
  `product_id` int(11) default NULL,
  `quantity` int(11) default NULL,
  `price` decimal(10,0) default NULL,
  PRIMARY KEY  (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `orders_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `orders_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders_items`
--


/*!40000 ALTER TABLE `orders_items` DISABLE KEYS */;
LOCK TABLES `orders_items` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `orders_items` ENABLE KEYS */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(128) default NULL,
  `image` varchar(128) default NULL,
  `description` text,
  `price` text,
  `danger` tinyint(1) default '1',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--


/*!40000 ALTER TABLE `products` DISABLE KEYS */;
LOCK TABLES `products` WRITE;
INSERT INTO `products` VALUES (1,'A Table','/img/uploads/2015-01-02_Xgxtm2.jpg','A very big table, useful for ... putting things on and possibly eating at.','110.00',0),(2,'A Lamp','/img/uploads/2015-01-02_lzfzpK.jpg','For lighting things up in a dark room.','60.00',0),(3,'A Drinks Globe and Chair','/img/uploads/2015-01-02_rN4jBX.jpg','A Drinks Globe, something that should be in everyone\'s home!','90.00',0),(4,'Rocks of Cocaine','/img/uploads/2015-01-05_48A2N6.jpg','Lots and lots of coke!','5000.00',1),(5,'Weed','/img/uploads/2015-01-05_JYIUmP.jpg','Plenty of weed. Top quality stuff.','40.00',1),(6,'Heroin','/img/uploads/2015-01-05_MUSlKg.jpg','More Class As for you!','6000.00',1),(7,'ZeuS Source Code','/img/uploads/2015-01-05_2F6zjh.jpg','Get the source code to deploy your own botnet.','500.00',1),(8,'BlackHole Crimeware','/img/uploads/2015-01-05_lPh78V.jpg','Start a bot, maintain and control it. Your own crimewave.','800.00',1),(9,'DDOS your enemies','/img/uploads/2015-01-05_qHt6s3.jpg','We use ZeuS to DDOS a target server of your choice.','100.00',1),(10,'Web hacking','/img/uploads/2015-01-05_btQvWF.jpg','Give us a URL and you have an hour of our work to bring down a site of your choice.','50.00',1),(11,'My Little Pony','/img/uploads/2015-01-05_f7rk0d.jpg','c5d571d35d00ddb9041a6cee04b8f283','999999.00',1);
UNLOCK TABLES;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

--
-- Table structure for table `token`
--

DROP TABLE IF EXISTS `token`;
CREATE TABLE `token` (
  `token` varchar(256) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `token`
--


/*!40000 ALTER TABLE `token` DISABLE KEYS */;
LOCK TABLES `token` WRITE;
INSERT INTO `token` VALUES ('d0180f6c29e6a27b05fa72fab1fcd333');
UNLOCK TABLES;
/*!40000 ALTER TABLE `token` ENABLE KEYS */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(128) default NULL,
  `full` varchar(128) default NULL,
  `password` varchar(128) default NULL,
  `is_dealer` tinyint(1) default '0',
  `email` varchar(128) default NULL,
  `killed_on` timestamp NULL default NULL,
  `killed_by` int(11) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `fk_killed` (`killed_by`),
  CONSTRAINT `fk_killed` FOREIGN KEY (`killed_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--


/*!40000 ALTER TABLE `users` DISABLE KEYS */;
LOCK TABLES `users` WRITE;
INSERT INTO `users` VALUES (1,'jts','John Saxon','*DC917E8329C06E9E7735775F8E8F5CF2F2AE1505',0,'j.t.saxon@cs.bham.ac.uk',NULL,NULL),(2,'tpc','Tom Chothia','*D13C4744CA50C108313F76D56E7C1C23F8844026',1,'t.chothia@cs.bham.ac.uk',NULL,NULL),(3,'csn','Chris Novakovic','*9C5B7560B497DFA8B05F1ED9E0D163FF1809DF7A',0,'c.novakovic@cs.bham.ac.uk','2015-01-02 16:39:01',2),(4,'igb','Ian Batten','*4A0F50F04E783107E072358BEB80DFD2CE206ABC',0,'i.batten@cs.bham.ac.uk','2015-01-02 16:39:01',2),(5,'air','Andreea Radu','*D03F2141E072304885CF0BB96B8E93B2F2F079E5',0,'a.i.radu@cs.bham.ac.uk',NULL,NULL);
UNLOCK TABLES;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

