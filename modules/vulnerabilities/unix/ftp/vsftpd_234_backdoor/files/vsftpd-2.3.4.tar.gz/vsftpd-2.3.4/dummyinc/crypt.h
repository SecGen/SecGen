#ifndef VSF_DUMMYINC_CRYPT_H
#define VSF_DUMMYINC_CRYPT_H

extern char* crypt(const char*, const char*);

#endif /* VSF_DUMMYINC_CRYPT_H */

